﻿//-----------------------------------------------------------------------
// <copyright file="$safeitemname$.cs" company="$Company$">
//     Class: $safeitemname$
//     Copyright © $Company$ $year$
// </copyright>
//
// <author>$Author$ - $Company$</author>
// <email>$Email$</email>
// <date>$time$</date>
//
// <summary>
// Beschreibung zum Dialog
// </summary>
//-----------------------------------------------------------------------

namespace $rootnamespace$
{
    using System.Windows;

    /// <summary>
    /// Interaktionslogik für $safeitemname$.xaml
    /// </summary>
    public partial class $safeitemname$ : Window
    {
        public $safeitemname$()
        {
            this.InitializeComponent();

            /* Dem DataContext ein ViewModel zuweisen
             * this.DataContext = ;
             */
        }
    }
}
