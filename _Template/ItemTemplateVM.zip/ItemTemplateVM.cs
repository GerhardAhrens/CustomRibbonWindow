//-----------------------------------------------------------------------
// <copyright file="$safeitemname$.cs" company="$Company$">
//     Class: $safeitemname$
//     Copyright � $Company$ $year$
// </copyright>
//
// <author>$Author$ - $Company$</author>
// <email>$Email$</email>
// <date>$time$</date>
//
// <summary>
// Beschreibung zur Klasse
// </summary>
//-----------------------------------------------------------------------

namespace $rootnamespace$
{
    using System.Windows;
    using System.Linq;

    using CustomRibbonWindow.Core;
    using CustomRibbonWindow.Core.BaseClass;

    public class $safeitemname$ : ViewModelBase
    {
        #region Commands
        public DelegateCommand DialogCloseCommand => new DelegateCommand(this.CloseDialog, this.CanCloseDialog);
        #endregion Commands

        /// <summary>
        /// Initializes a new instance of the <see cref="DialogEinsVM"/> class.
        /// </summary>
        public $safeitemname$()
        {
            this.DialogTitle.Value = "Dialog Beschreibung";
            this.LoadData();
        }

        public BindableObjectProperty<string> DialogTitle { get; set; } = new BindableObjectProperty<string>();


        private void LoadData()
        {
            StatusbarDialog.Notification = "Bereit";
            base.IsModified = false;
        }

        private void CloseDialog(object parameter)
        {
            Window currentWindow = Application.Current.Windows.Cast<Window>().Single(s => s.IsActive == true);
            if (currentWindow != null)
            {
                currentWindow.Close();
            }
        }

        private bool CanCloseDialog()
        {
            return true;
        }
    }
}
